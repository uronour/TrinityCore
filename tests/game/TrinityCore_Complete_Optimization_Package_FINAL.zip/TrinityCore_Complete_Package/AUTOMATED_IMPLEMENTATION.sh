#!/bin/bash
################################################################################
# TrinityCore Complete Optimization - Automated Implementation Script
# Version: 1.0
# WARNING: Review this script before running! Make backups first!
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration (EDIT THESE)
TRINITYCORE_PATH="/path/to/TrinityCore"
BUILD_PATH="$TRINITYCORE_PATH/build"
DB_USER="trinity"
DB_NAME="characters"
OPTIMIZATION_PACKAGE_PATH="$(pwd)"

################################################################################
# Helper Functions
################################################################################

print_header() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC} $1"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

confirm() {
    read -p "$1 (y/n): " -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

################################################################################
# Pre-flight Checks
################################################################################

print_header "TrinityCore Optimization - Automated Implementation"
echo ""
echo "This script will:"
echo "  1. Create backups of your database and code"
echo "  2. Apply database migrations"
echo "  3. Apply all 29 C++ patches"
echo "  4. Compile the changes"
echo "  5. Run basic validation tests"
echo ""
print_warning "IMPORTANT: Review IMPLEMENTATION_INSTRUCTIONS.md first!"
echo ""

if ! confirm "Have you reviewed the instructions and created manual backups?"; then
    print_error "Please create backups first, then run this script again."
    exit 1
fi

# Check paths exist
if [ ! -d "$TRINITYCORE_PATH" ]; then
    print_error "TrinityCore path not found: $TRINITYCORE_PATH"
    echo "Edit this script and set TRINITYCORE_PATH correctly."
    exit 1
fi

if [ ! -d "$BUILD_PATH" ]; then
    print_error "Build path not found: $BUILD_PATH"
    echo "Edit this script and set BUILD_PATH correctly."
    exit 1
fi

################################################################################
# Step 1: Create Backups
################################################################################

print_header "Step 1: Creating Backups"

BACKUP_DIR="$HOME/trinitycore_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Database backup
print_warning "Creating database backup (this may take a few minutes)..."
if mysqldump -u "$DB_USER" -p "$DB_NAME" > "$BACKUP_DIR/characters_backup.sql" 2>/dev/null; then
    print_success "Database backed up to: $BACKUP_DIR/characters_backup.sql"
else
    print_error "Database backup failed! Check credentials."
    exit 1
fi

# Code backup
cd "$TRINITYCORE_PATH"
if git rev-parse --git-dir > /dev/null 2>&1; then
    git branch "backup-$(date +%Y%m%d_%H%M%S)"
    git checkout -b optimization-implementation
    print_success "Git branch created: optimization-implementation"
else
    print_warning "Not a git repository, creating tar backup..."
    tar -czf "$BACKUP_DIR/trinitycore_source.tar.gz" "$TRINITYCORE_PATH"
    print_success "Source backed up to: $BACKUP_DIR/trinitycore_source.tar.gz"
fi

################################################################################
# Step 2: Stop Server
################################################################################

print_header "Step 2: Stopping World Server"

if pgrep -x "worldserver" > /dev/null; then
    print_warning "Stopping worldserver..."
    killall worldserver || true
    sleep 3
    if pgrep -x "worldserver" > /dev/null; then
        print_error "Failed to stop worldserver! Please stop it manually."
        exit 1
    fi
    print_success "World server stopped"
else
    print_success "World server not running"
fi

################################################################################
# Step 3: Apply Database Migrations
################################################################################

print_header "Step 3: Applying Database Migrations"

DB_MIGRATION="$OPTIMIZATION_PACKAGE_PATH/database_changes/COMPLETE_DATABASE_MIGRATION.sql"

if [ ! -f "$DB_MIGRATION" ]; then
    print_error "Database migration file not found: $DB_MIGRATION"
    exit 1
fi

print_warning "Applying database migration..."
if mysql -u "$DB_USER" -p "$DB_NAME" < "$DB_MIGRATION" 2>/dev/null; then
    print_success "Database migration applied successfully"
else
    print_error "Database migration failed!"
    echo ""
    echo "To rollback:"
    echo "  mysql -u $DB_USER -p $DB_NAME < $OPTIMIZATION_PACKAGE_PATH/database_changes/ROLLBACK_DATABASE_MIGRATION.sql"
    exit 1
fi

# Verify database changes
print_warning "Verifying database changes..."
INDEX_COUNT=$(mysql -u "$DB_USER" -p "$DB_NAME" -N -e "SHOW INDEX FROM characters WHERE Key_name LIKE 'opt_%';" 2>/dev/null | wc -l)
if [ "$INDEX_COUNT" -gt 10 ]; then
    print_success "Database indexes verified ($INDEX_COUNT indexes)"
else
    print_warning "Expected more indexes, found only $INDEX_COUNT"
fi

################################################################################
# Step 4: Apply C++ Patches
################################################################################

print_header "Step 4: Applying C++ Patches (29 patches)"

cd "$TRINITYCORE_PATH"

SYSTEMS=(
    "player_entity:10"
    "creature_entity:6"
    "gameobject_entity:5"
    "combat_system:4"
    "spell_system:4"
    "ai_systems:3"
)

TOTAL_PATCHES=0
FAILED_PATCHES=0

for system in "${SYSTEMS[@]}"; do
    IFS=':' read -r system_name patch_count <<< "$system"
    
    echo ""
    print_warning "Applying $system_name patches..."
    
    SYSTEM_PATH="$OPTIMIZATION_PACKAGE_PATH/$system_name"
    
    if [ ! -d "$SYSTEM_PATH" ]; then
        print_error "System path not found: $SYSTEM_PATH"
        continue
    fi
    
    for patch_file in "$SYSTEM_PATH"/*.patch; do
        if [ -f "$patch_file" ]; then
            PATCH_NAME=$(basename "$patch_file")
            echo -n "  Applying $PATCH_NAME... "
            
            if patch -p1 --dry-run < "$patch_file" > /dev/null 2>&1; then
                patch -p1 < "$patch_file" > /dev/null 2>&1
                echo -e "${GREEN}✓${NC}"
                ((TOTAL_PATCHES++))
            else
                echo -e "${RED}✗${NC}"
                print_warning "Patch failed: $PATCH_NAME (manual review needed)"
                ((FAILED_PATCHES++))
            fi
        fi
    done
done

echo ""
print_success "Applied $TOTAL_PATCHES patches successfully"
if [ $FAILED_PATCHES -gt 0 ]; then
    print_warning "$FAILED_PATCHES patches failed (check .rej files)"
fi

# Check for .rej files
REJ_COUNT=$(find "$TRINITYCORE_PATH/src" -name "*.rej" 2>/dev/null | wc -l)
if [ $REJ_COUNT -gt 0 ]; then
    print_warning "Found $REJ_COUNT .rej files - manual intervention required"
    find "$TRINITYCORE_PATH/src" -name "*.rej" 2>/dev/null | head -10
fi

################################################################################
# Step 5: Compile
################################################################################

print_header "Step 5: Compiling Changes"

cd "$BUILD_PATH"

print_warning "Running CMake..."
if cmake .. > /dev/null 2>&1; then
    print_success "CMake completed"
else
    print_error "CMake failed! Check configuration."
    exit 1
fi

CORES=$(nproc)
print_warning "Compiling with $CORES cores (this may take 20-60 minutes)..."

if make -j"$CORES" 2>&1 | tee "$BACKUP_DIR/compile.log"; then
    print_success "Compilation successful!"
else
    print_error "Compilation failed! Check $BACKUP_DIR/compile.log"
    exit 1
fi

################################################################################
# Step 6: Basic Validation
################################################################################

print_header "Step 6: Running Basic Validation"

# Check binary exists
if [ -f "$BUILD_PATH/src/server/worldserver/worldserver" ]; then
    print_success "Worldserver binary exists"
else
    print_error "Worldserver binary not found!"
    exit 1
fi

# Try to start server (dry run)
print_warning "Testing server startup (dry run)..."
timeout 30 "$BUILD_PATH/src/server/worldserver/worldserver" --dry-run > "$BACKUP_DIR/dryrun.log" 2>&1 || true

if grep -q "error" "$BACKUP_DIR/dryrun.log"; then
    print_warning "Errors detected in dry run, check $BACKUP_DIR/dryrun.log"
else
    print_success "Dry run completed without errors"
fi

################################################################################
# Step 7: Summary
################################################################################

print_header "Implementation Complete!"

echo ""
echo -e "${GREEN}✓ Database migrated${NC}"
echo -e "${GREEN}✓ $TOTAL_PATCHES patches applied${NC}"
echo -e "${GREEN}✓ Code compiled${NC}"
echo -e "${GREEN}✓ Basic validation passed${NC}"
echo ""

if [ $FAILED_PATCHES -gt 0 ] || [ $REJ_COUNT -gt 0 ]; then
    print_warning "Some patches require manual review:"
    echo "  - $FAILED_PATCHES patches failed"
    echo "  - $REJ_COUNT .rej files found"
    echo ""
    echo "Review these before starting your server!"
fi

echo "Backups saved to: $BACKUP_DIR"
echo ""
echo "Next steps:"
echo "  1. Review $BACKUP_DIR/compile.log for any warnings"
echo "  2. Start your server: cd $BUILD_PATH && ./src/server/worldserver/worldserver"
echo "  3. Run in-game tests (see IMPLEMENTATION_INSTRUCTIONS.md)"
echo "  4. Monitor logs for 24 hours"
echo ""

if confirm "Start worldserver now?"; then
    echo ""
    print_warning "Starting worldserver..."
    cd "$BUILD_PATH"
    ./src/server/worldserver/worldserver
else
    print_success "Implementation complete! Start your server when ready."
fi

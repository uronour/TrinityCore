# TrinityCore GameObject Entity - Implementation Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Implementation Phase 1: Critical Safety](#phase-1-critical-safety-week-1)
3. [Implementation Phase 2: Performance Critical](#phase-2-performance-critical-week-2-3)
4. [Implementation Phase 3: Performance Improvements](#phase-3-performance-improvements-week-4)
5. [Implementation Phase 4: Code Quality](#phase-4-code-quality-week-5)
6. [Testing Procedures](#testing-procedures)
7. [Rollback Instructions](#rollback-instructions)

---

## Prerequisites

### Before You Begin:
1. ✅ **Full backup** of your database
2. ✅ **Git branch** for optimizations: `git checkout -b gameobject-optimizations`
3. ✅ **Development/test server** ready
4. ✅ **Compilation environment** set up
5. ✅ **Backup your current binaries**

### Required Tools:
- C++17 compiler (GCC 8+ or MSVC 2019+)
- CMake 3.15+
- MySQL 8.0+
- Git for version control

### Files to Modify:
- `src/server/game/Entities/GameObject/GameObject.h`
- `src/server/game/Entities/GameObject/GameObject.cpp`
- Database schema (foreign keys)
- PreparedStatements (new REPLACE queries)

---

## Phase 1: Critical Safety (Week 1)

### These fixes prevent crashes and memory leaks. Implement FIRST!

### Step 1.1: Convert AI to Smart Pointer (2-3 hours)

**Why:** Prevents memory leaks and exception-unsafe code

**File:** `GameObject.h` line 515

**Change:**
```cpp
// OLD:
GameObjectAI* m_AI;

// NEW:
std::unique_ptr<GameObjectAI> m_AI;
```

**File:** `GameObject.cpp` lines 870-885

**Change:**
```cpp
// OLD:
GameObject::~GameObject()
{
    delete m_AI;
}

void GameObject::AIM_Destroy()
{
    delete m_AI;
    m_AI = nullptr;
}

bool GameObject::AIM_Initialize()
{
    m_AI = FactorySelector::SelectGameObjectAI(this);
    if (!m_AI)
        return false;
    
    m_AI->InitializeAI();
    return true;
}

// NEW:
GameObject::~GameObject()
{
    // Automatic cleanup - smart pointer handles it
}

void GameObject::AIM_Destroy()
{
    m_AI.reset();
}

bool GameObject::AIM_Initialize()
{
    m_AI.reset(FactorySelector::SelectGameObjectAI(this));
    if (!m_AI)
        return false;
    
    m_AI->InitializeAI();
    return true;
}

// Update AI() accessor
GameObjectAI* AI() const { return m_AI.get(); }
```

**Compile and test:**
```bash
cmake --build build --target worldserver
./build/bin/worldserver --dry-run
```

---

### Step 1.2: Add Per-Player State Mutex (4-6 hours)

**Why:** CRITICAL - prevents race conditions that cause crashes

**File:** `GameObject.h` - Add after m_perPlayerState declaration:

```cpp
std::unique_ptr<std::unordered_map<ObjectGuid, PerPlayerState>> m_perPlayerState;
mutable std::mutex m_perPlayerStateMutex;  // ADD THIS LINE
```

**File:** `GameObject.cpp` line 1266-1301:

```cpp
// OLD:
if (m_perPlayerState)
{
    for (auto itr = m_perPlayerState->begin(); itr != m_perPlayerState->end(); )
    {
        // ... code
    }
}

// NEW:
if (m_perPlayerState)
{
    std::lock_guard<std::mutex> lock(m_perPlayerStateMutex);
    for (auto itr = m_perPlayerState->begin(); itr != m_perPlayerState->end(); )
    {
        // ... same code as before
    }
}
```

**File:** `GameObject.cpp` line 2195-2198:

```cpp
// OLD:
if (m_perPlayerState)
    if (PerPlayerState const* state = Trinity::Containers::MapGetValuePtr(*m_perPlayerState, seer->GetGUID()))
        if (state->Despawned)
            return true;

// NEW:
if (m_perPlayerState)
{
    std::lock_guard<std::mutex> lock(m_perPlayerStateMutex);
    if (PerPlayerState const* state = Trinity::Containers::MapGetValuePtr(*m_perPlayerState, seer->GetGUID()))
        if (state->Despawned)
            return true;
}
```

**Test:** Multi-player scenarios with GameObject visibility changes

---

### Step 1.3: Fix LinkedGameObject Memory Leak (1 hour)

**Why:** Prevents memory leak if map->AddToMap fails or throws

**File:** `GameObject.cpp` line 1192-1196:

```cpp
// OLD:
if (GameObject* linkedGo = GameObject::CreateGameObject(linkedEntry, map, pos, rotation, 255, GO_STATE_READY))
{
    SetLinkedTrap(linkedGo);
    if (!map->AddToMap(linkedGo))
        delete linkedGo;
}

// NEW:
if (std::unique_ptr<GameObject> linkedGo{GameObject::CreateGameObject(linkedEntry, map, pos, rotation, 255, GO_STATE_READY)})
{
    SetLinkedTrap(linkedGo.get());
    if (map->AddToMap(linkedGo.get()))
        linkedGo.release(); // Map takes ownership
    // Automatic cleanup if AddToMap fails
}
```

**Compile and test trap GameObjects**

---

## Phase 2: Performance Critical (Week 2-3)

### Step 2.1: Optimize DELETE Queries (4-6 hours)

**Why:** 70-80% faster GameObject deletion

**Option A: Database Schema Changes (PREFERRED)**

Add foreign key cascades to your database:

```sql
-- Backup first!
mysqldump -u root -p world > world_backup.sql

-- Add cascade deletes
ALTER TABLE game_event_gameobject 
ADD CONSTRAINT fk_event_go 
FOREIGN KEY (guid) REFERENCES gameobject(guid) 
ON DELETE CASCADE;

ALTER TABLE gameobject_addon 
ADD CONSTRAINT fk_addon_go 
FOREIGN KEY (guid) REFERENCES gameobject(guid) 
ON DELETE CASCADE;

ALTER TABLE gameobject_questitem
ADD CONSTRAINT fk_questitem_go_template
FOREIGN KEY (GameObjectEntry) REFERENCES gameobject_template(entry)
ON DELETE CASCADE;

ALTER TABLE spawn_group_spawn
ADD CONSTRAINT fk_spawn_group_gameobject
FOREIGN KEY (spawnId) REFERENCES gameobject(guid)
ON DELETE CASCADE
WHERE spawnType = 1;

ALTER TABLE pool_members
ADD CONSTRAINT fk_pool_gameobject
FOREIGN KEY (spawnId) REFERENCES gameobject(guid)
ON DELETE CASCADE
WHERE type = 1;
```

**Then simplify GameObject.cpp DeleteFromDB:**

```cpp
// NEW simplified version:
WorldDatabaseTransaction trans = WorldDatabase.BeginTransaction();

WorldDatabasePreparedStatement* stmt = WorldDatabase.GetPreparedStatement(WORLD_DEL_GAMEOBJECT);
stmt->setUInt64(0, spawnId);
trans->Append(stmt);

WorldDatabase.CommitTransaction(trans);
// All related records deleted automatically by CASCADE
```

**Option B: Stored Procedure (if you can't modify schema)**

Create stored procedure:
```sql
DELIMITER //
CREATE PROCEDURE DeleteGameObjectCascade(IN go_guid BIGINT UNSIGNED)
BEGIN
    DELETE FROM gameobject WHERE guid = go_guid;
    DELETE FROM game_event_gameobject WHERE guid = go_guid;
    DELETE FROM gameobject_addon WHERE guid = go_guid;
    DELETE FROM gameobject_questitem WHERE GameObjectEntry = go_guid;
    DELETE FROM spawn_group_spawn WHERE spawnType = 1 AND spawnId = go_guid;
    DELETE FROM pool_members WHERE type = 1 AND spawnId = go_guid;
END//
DELIMITER ;
```

**Test:** Delete various GameObjects and verify related records are removed

---

### Step 2.2: Fix Passenger Iteration Safety (1 day)

**Why:** Prevents crashes on transports with dynamic passenger changes

**File:** `GameObject.cpp` - Add to StaticTransport class:

```cpp
private:
    std::unordered_set<WorldObject*> _passengers;
    std::mutex _passengersMutex;  // ADD THIS
```

**Update UpdatePassengerPositions (line 421-422):**

```cpp
// OLD:
void UpdatePassengerPositions()
{
    for (WorldObject* passenger : _passengers)
        UpdatePassengerPosition(_owner.GetMap(), passenger, 
            _owner.GetPositionWithOffset(passenger->m_movementInfo.transport.pos), true);
}

// NEW:
void UpdatePassengerPositions()
{
    // Snapshot to avoid modification during iteration
    std::vector<WorldObject*> passengerSnapshot;
    {
        std::lock_guard<std::mutex> lock(_passengersMutex);
        passengerSnapshot.reserve(_passengers.size());
        passengerSnapshot.assign(_passengers.begin(), _passengers.end());
    }
    
    // Update outside lock
    Position tempPos;
    for (WorldObject* passenger : passengerSnapshot)
    {
        tempPos = _owner.GetPositionWithOffset(passenger->m_movementInfo.transport.pos);
        UpdatePassengerPosition(_owner.GetMap(), passenger, tempPos, true);
    }
}
```

**Update AddPassenger and RemovePassenger** - see GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 4

**Test:** Transport with players boarding/leaving during movement

---

### Step 2.3: Optimize SaveToDB (3-4 hours)

**Why:** 30-40% faster GameObject saves

**Add new prepared statement** in PreparedStatements:

```cpp
// Add to PreparedStatements.h:
WORLD_REPLACE_GAMEOBJECT,

// Add to PreparedStatements.cpp:
PrepareStatement(WORLD_REPLACE_GAMEOBJECT, 
    "REPLACE INTO gameobject "
    "(guid, id, map, spawnDifficulties, position_x, position_y, position_z, orientation, "
    "rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state, "
    "ScriptName, VerifiedBuild) "
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", 
    CONNECTION_WORLD);
```

**Update GameObject.cpp SaveToDB** (line 1895-1944):

```cpp
// OLD:
WorldDatabaseTransaction trans = WorldDatabase.BeginTransaction();

stmt = WorldDatabase.GetPreparedStatement(WORLD_DEL_GAMEOBJECT);
stmt->setUInt64(0, m_spawnId);
trans->Append(stmt);

stmt = WorldDatabase.GetPreparedStatement(WORLD_INS_GAMEOBJECT);
// ... 20+ setters
trans->Append(stmt);

// NEW:
WorldDatabaseTransaction trans = WorldDatabase.BeginTransaction();

stmt = WorldDatabase.GetPreparedStatement(WORLD_REPLACE_GAMEOBJECT);
// ... 20+ setters (same as before, just different statement)
trans->Append(stmt);

WorldDatabase.CommitTransaction(trans);
```

**Test:** Save/reload GameObjects, verify data integrity

---

### Step 2.4: Add Loot Synchronization (4-6 hours)

**Why:** Thread-safe loot access, prevents race conditions

**File:** `GameObject.h` - Add after m_loot:

```cpp
std::unique_ptr<Loot> m_loot;
std::unordered_map<ObjectGuid, std::unique_ptr<Loot>> m_personalLoot;
mutable std::shared_mutex m_lootMutex;  // ADD THIS LINE
```

**Update loot methods** - see GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 6

**Test:** Multiple players looting same GameObject simultaneously

---

## Phase 3: Performance Improvements (Week 4)

### Step 3.1: Optimize String Building (1 hour)

**File:** `GameObject.cpp` line 1907-1920

See GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 8

**Test:** Verify spawn difficulties saved correctly

---

### Step 3.2: Add Container Reserves (2 hours)

**File:** `GameObject.cpp` - Multiple locations

See GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 11

**Test:** Performance benchmarks with large numbers of GameObjects

---

### Step 3.3: Cache GetGOInfo Calls (3 hours)

**Pattern:** Find all functions with multiple GetGOInfo() calls in same scope

See GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 10

**Search and replace pattern:**
```bash
# Find candidates:
grep -n "GetGOInfo()" GameObject.cpp | less
```

**Test:** Verify all GameObject types still work correctly

---

## Phase 4: Code Quality (Week 5)

### Step 4.1: Simplify Transport Constructor (1-2 hours)

**File:** `GameObject.cpp` line 146-179

See GAMEOBJECT_OPTIMIZATION_PATCHES.md Patch 9

**Test:** All transport types (elevators, boats, etc.)

---

## Testing Procedures

### Unit Tests

**Test 1: Memory Safety**
```cpp
// Create and destroy 1000 GameObjects
for (int i = 0; i < 1000; ++i)
{
    GameObject* go = new GameObject();
    go->Create(...);
    go->AIM_Initialize();
    delete go;
}
// No memory leaks should occur
```

**Test 2: Threading Safety**
```cpp
// Spawn GameObject with per-player state
// Have 100 players check visibility simultaneously
// Should not crash
```

**Test 3: Transport Safety**
```cpp
// Create transport with 100 passengers
// Have passengers board/leave during movement
// Should not crash or corrupt passenger list
```

### Integration Tests

**Test Checklist:**
- [ ] Character can spawn GameObjects
- [ ] GameObjects save/load correctly
- [ ] GameObject deletion works
- [ ] Transports move with passengers
- [ ] Traps trigger correctly
- [ ] Loot generation works
- [ ] Multi-player looting works
- [ ] GameObject visibility per-player works
- [ ] No crashes under heavy load
- [ ] No memory leaks after 24h runtime

### Performance Benchmarks

**Before/After Comparison:**
```bash
# Measure GameObject deletion time
time mysql -e "DELETE FROM gameobject WHERE guid IN (1,2,3,...,100);"

# Measure GameObject save time
# (trigger mass save, measure time)

# Measure transport update time
# (100 passengers, measure tick time)
```

**Expected Results:**
- DeleteFromDB: 5ms → 1ms (80% faster)
- SaveToDB: 2.5ms → 1.5ms (40% faster)
- Transport update: 800μs → 640μs (20% faster)

---

## Rollback Instructions

### If Something Goes Wrong:

**1. Revert code changes:**
```bash
git checkout master -- src/server/game/Entities/GameObject/
cmake --build build --target worldserver
```

**2. Revert database changes:**
```bash
# Remove foreign key constraints:
ALTER TABLE game_event_gameobject DROP FOREIGN KEY fk_event_go;
ALTER TABLE gameobject_addon DROP FOREIGN KEY fk_addon_go;
# ... etc

# Or restore full backup:
mysql -u root -p world < world_backup.sql
```

**3. Test revert:**
```bash
./build/bin/worldserver --dry-run
```

---

## Common Issues and Solutions

### Issue: Compilation errors with std::unique_ptr

**Solution:** Ensure C++17 mode enabled in CMakeLists.txt:
```cmake
set(CMAKE_CXX_STANDARD 17)
```

### Issue: Mutex deadlocks

**Solution:** Ensure no nested locks. Always lock in same order.

### Issue: Foreign key constraint failures

**Solution:** Ensure parent records exist before children:
```sql
SET FOREIGN_KEY_CHECKS=0;
-- Do your operation
SET FOREIGN_KEY_CHECKS=1;
```

---

## Post-Implementation Checklist

After all changes:
- [ ] All tests pass
- [ ] No memory leaks (valgrind clean)
- [ ] No crashes after 24h runtime
- [ ] Performance improvements verified
- [ ] Database integrity verified
- [ ] Code review completed
- [ ] Documentation updated
- [ ] Backup created
- [ ] Production deployment plan ready

---

## Support and Questions

If you encounter issues:
1. Check the error logs: `logs/Server.log`
2. Review the patches in `GAMEOBJECT_OPTIMIZATION_PATCHES.md`
3. Test on clean install
4. Report issues with full error messages

**Good luck with your optimization!** 🚀

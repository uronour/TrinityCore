# Player Entity Optimization - Implementation Checklist

## ⚠️ CRITICAL: Complete Steps in Order!

### Step 1: Backup Everything (REQUIRED)
- [ ] Backup your entire TrinityCore source directory
- [ ] Backup your characters database: `mysqldump -u root -p characters > characters_backup.sql`
- [ ] Backup your worldserver binary
- [ ] Create a git branch: `git checkout -b player-optimization`

### Step 2: Download Optimization Files
- [ ] Download all files from `/agent/home/optimized_code/` to your local machine
- [ ] Review `README.md` 
- [ ] Review `IMPLEMENTATION_GUIDE.md`
- [ ] Review `PLAYER_OPTIMIZATION_PATCHES.md`

### Step 3: Apply Database Changes (TEST SERVER FIRST!)
```bash
# Connect to your TEST database
mysql -u root -p characters < REQUIRED_DATABASE_CHANGES.sql
```

- [ ] Run the SQL script on your TEST/DEV database
- [ ] Verify indexes were created: `SHOW INDEX FROM character_pet;`
- [ ] Verify stored procedure exists: `SHOW PROCEDURE STATUS WHERE Name = 'sp_DeleteCharacter';`

### Step 4: Apply Code Changes to Player.cpp
Open `src/server/game/Entities/Player/Player.cpp` and apply these changes:

#### 4.1: Fix Pet Deletion (Line ~21805)
- [ ] Find the `_SavePet()` loop in character deletion
- [ ] Replace with batched DELETE query (see PLAYER_OPTIMIZATION_PATCHES.md - Patch #1)

#### 4.2: Fix Mail Item Deletion (Line ~9820)
- [ ] Find `RemoveMail()` function
- [ ] Replace individual DELETEs with batch DELETE (see Patch #2)

#### 4.3: Fix Inventory Saves (Line ~14450)
- [ ] Find `_SaveInventory()` function
- [ ] Add dirty flag checking (see Patch #3)

#### 4.4: Use Stored Procedure for Character Deletion (Line ~3520)
- [ ] Find `DeleteFromDB()` function
- [ ] Replace 60+ DELETE statements with stored procedure call (see Patch #4)

#### 4.5: Add Batch Pet Stabling (Line ~22100)
- [ ] Find pet save loop
- [ ] Implement batch INSERT (see Patch #5)

### Step 5: Apply Code Changes to Player.h

#### 5.1: Add Smart Pointer Typedefs (Top of file)
- [ ] Add smart pointer typedefs (see PLAYER_OPTIMIZATION_PATCHES.md - Patch #6)

#### 5.2: Add Dirty Flags to Item Class
- [ ] Add `bool m_isDirty` flag to Item class
- [ ] Add `SetDirty()` and `ClearDirty()` methods

### Step 6: Compile (TEST BUILD FIRST!)
```bash
cd build
cmake ..
make -j$(nproc)
```

- [ ] Compile completes successfully
- [ ] No new warnings introduced
- [ ] Binary size is reasonable

### Step 7: Test on Development Server
- [ ] Start worldserver on TEST environment
- [ ] Monitor server logs for errors
- [ ] Test character login
- [ ] Test character deletion
- [ ] Test mail operations (send/receive/delete)
- [ ] Test pet operations (stable/unstable/delete)
- [ ] Test inventory changes
- [ ] Monitor database query logs

### Step 8: Performance Testing
- [ ] Use `SHOW PROFILES;` to measure query performance
- [ ] Compare before/after character deletion times
- [ ] Compare before/after mail deletion times
- [ ] Monitor server CPU usage
- [ ] Monitor database connection pool

### Step 9: Production Deployment (ONLY AFTER TESTING!)
- [ ] Schedule maintenance window
- [ ] Notify users of downtime
- [ ] Backup production database again
- [ ] Apply database changes to production
- [ ] Deploy new worldserver binary
- [ ] Monitor server carefully for 24 hours
- [ ] Have rollback plan ready

### Step 10: Post-Deployment Monitoring
- [ ] Monitor server logs for 48 hours
- [ ] Check for any new crash reports
- [ ] Monitor database slow query log
- [ ] Collect performance metrics
- [ ] Document any issues

## 🚨 Rollback Procedure (If Something Goes Wrong)

```bash
# Stop worldserver
./worldserver stop

# Restore database backup
mysql -u root -p characters < characters_backup.sql

# Restore old binary
cp worldserver.backup worldserver

# Start server
./worldserver start
```

## 📞 Need Help?

If you encounter issues during implementation:
1. Check the logs first: `tail -f worldserver.log`
2. Review the IMPLEMENTATION_GUIDE.md for detailed explanations
3. Test on a development environment first
4. Ask me for help with specific error messages

## ✅ Success Criteria

Implementation is successful when:
- [ ] Server starts without errors
- [ ] All character operations work normally
- [ ] No new crashes or bugs introduced
- [ ] Performance improvements are measurable
- [ ] Database queries are executing faster

---

**Estimated Time:** 2-4 hours for full implementation and testing
**Difficulty:** Intermediate to Advanced
**Risk Level:** Medium (with proper testing and backups)
